    <div style="clear:both;color:#aaa; padding:20px;">
    	<hr /><center>&copy; <?php date('Y') ?> <a target="_blank" href=""> <?=$system_name ?></a></center>
    </div>
    
